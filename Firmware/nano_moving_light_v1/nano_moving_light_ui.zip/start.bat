@echo off
title Nano Moving Light Controller
echo.
echo  =======================================
echo   NANO MOVING LIGHT - Controller Setup
echo  =======================================
echo.

:: Check Python
python --version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Python not found. Please install Python from https://python.org
    pause
    exit /b 1
)

:: Install dependencies
echo [1/2] Installing dependencies...
pip install -r requirements.txt --quiet
if errorlevel 1 (
    echo [ERROR] pip install failed.
    pause
    exit /b 1
)

:: Open browser after short delay
echo [2/2] Starting server...
start "" /b timeout /t 2 /nobreak >nul && start "" "http://localhost:5000"

:: Start Flask
python app.py

pause
