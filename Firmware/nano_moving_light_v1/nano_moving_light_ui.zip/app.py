"""
Nano Moving Light – Flask Backend
Bridges the browser UI to the ESP32-C3 over Serial (USB-C)
"""

from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
import serial
import serial.tools.list_ports
import json
import os
import time
import threading

app = Flask(__name__, static_folder="static")
CORS(app)

# ── State ─────────────────────────────────────────────────────────
ser = None
serial_lock = threading.Lock()
CUES_FILE = "cues.json"

# ── Serial helpers ────────────────────────────────────────────────

def list_ports():
    ports = serial.tools.list_ports.comports()
    return [{"port": p.device, "description": p.description} for p in ports]

def connect_serial(port, baud=115200):
    global ser
    with serial_lock:
        if ser and ser.is_open:
            ser.close()
        ser = serial.Serial(port, baud, timeout=1)
        time.sleep(2)  # wait for ESP32 reset
    return True

def send_command(cmd: str):
    global ser
    with serial_lock:
        if ser and ser.is_open:
            ser.write((cmd.strip() + "\n").encode("utf-8"))
            time.sleep(0.02)
            response = ""
            while ser.in_waiting:
                response += ser.readline().decode("utf-8", errors="ignore")
            return response.strip()
    return "NOT_CONNECTED"

# ── Cue helpers ───────────────────────────────────────────────────

def load_cues():
    if os.path.exists(CUES_FILE):
        with open(CUES_FILE, "r") as f:
            return json.load(f)
    return []

def save_cues(cues):
    with open(CUES_FILE, "w") as f:
        json.dump(cues, f, indent=2)

def cue_to_command(cue):
    return f"R:{cue['r']},G:{cue['g']},B:{cue['b']},W:{cue['w']},PAN:{cue['pan']},TILT:{cue['tilt']}"

# ── API Routes ────────────────────────────────────────────────────

@app.route("/")
def index():
    return send_from_directory("static", "index.html")

@app.route("/api/ports")
def api_ports():
    return jsonify(list_ports())

@app.route("/api/connect", methods=["POST"])
def api_connect():
    data = request.json
    port = data.get("port")
    try:
        connect_serial(port)
        return jsonify({"status": "ok", "port": port})
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

@app.route("/api/disconnect", methods=["POST"])
def api_disconnect():
    global ser
    with serial_lock:
        if ser and ser.is_open:
            ser.close()
    return jsonify({"status": "ok"})

@app.route("/api/status")
def api_status():
    global ser
    connected = ser is not None and ser.is_open
    port = ser.port if connected else None
    return jsonify({"connected": connected, "port": port})

@app.route("/api/send", methods=["POST"])
def api_send():
    data = request.json
    cmd = data.get("command", "")
    if not cmd:
        return jsonify({"status": "error", "message": "No command"}), 400
    response = send_command(cmd)
    return jsonify({"status": "ok", "response": response})

# ── Cue API ───────────────────────────────────────────────────────

@app.route("/api/cues", methods=["GET"])
def api_get_cues():
    return jsonify(load_cues())

@app.route("/api/cues", methods=["POST"])
def api_save_cue():
    cues = load_cues()
    cue = request.json
    cue["id"] = int(time.time() * 1000)
    cues.append(cue)
    save_cues(cues)
    return jsonify({"status": "ok", "cue": cue})

@app.route("/api/cues/<int:cue_id>", methods=["PUT"])
def api_update_cue(cue_id):
    cues = load_cues()
    for i, c in enumerate(cues):
        if c["id"] == cue_id:
            cues[i] = {**c, **request.json, "id": cue_id}
            save_cues(cues)
            return jsonify({"status": "ok"})
    return jsonify({"status": "error", "message": "Not found"}), 404

@app.route("/api/cues/<int:cue_id>", methods=["DELETE"])
def api_delete_cue(cue_id):
    cues = load_cues()
    cues = [c for c in cues if c["id"] != cue_id]
    save_cues(cues)
    return jsonify({"status": "ok"})

@app.route("/api/cues/<int:cue_id>/fire", methods=["POST"])
def api_fire_cue(cue_id):
    cues = load_cues()
    for c in cues:
        if c["id"] == cue_id:
            cmd = cue_to_command(c)
            response = send_command(cmd)
            return jsonify({"status": "ok", "command": cmd, "response": response})
    return jsonify({"status": "error", "message": "Not found"}), 404

# ── Sequencer ─────────────────────────────────────────────────────

sequencer_thread = None
sequencer_running = False

def run_sequencer(cue_ids, interval_ms, loop):
    global sequencer_running
    cues = load_cues()
    cue_map = {c["id"]: c for c in cues}
    selected = [cue_map[cid] for cid in cue_ids if cid in cue_map]
    if not selected:
        sequencer_running = False
        return
    while sequencer_running:
        for cue in selected:
            if not sequencer_running:
                break
            send_command(cue_to_command(cue))
            time.sleep(interval_ms / 1000.0)
        if not loop:
            break
    sequencer_running = False

@app.route("/api/sequencer/start", methods=["POST"])
def api_seq_start():
    global sequencer_thread, sequencer_running
    data = request.json
    cue_ids = data.get("cue_ids", [])
    interval_ms = data.get("interval_ms", 1000)
    loop = data.get("loop", True)

    sequencer_running = False
    if sequencer_thread and sequencer_thread.is_alive():
        sequencer_thread.join(timeout=2)

    sequencer_running = True
    sequencer_thread = threading.Thread(
        target=run_sequencer, args=(cue_ids, interval_ms, loop), daemon=True
    )
    sequencer_thread.start()
    return jsonify({"status": "ok"})

@app.route("/api/sequencer/stop", methods=["POST"])
def api_seq_stop():
    global sequencer_running
    sequencer_running = False
    return jsonify({"status": "ok"})

@app.route("/api/sequencer/status")
def api_seq_status():
    return jsonify({"running": sequencer_running})

# ── Main ──────────────────────────────────────────────────────────

if __name__ == "__main__":
    os.makedirs("static", exist_ok=True)
    print("🎛  Nano Moving Light Controller")
    print("   Open http://localhost:5000 in your browser")
    app.run(debug=False, port=5000)
